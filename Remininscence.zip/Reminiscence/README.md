# culpa
This project is created from scratch by an unemployed student who has no degree or took no course in computer science/IT/programming. It would be really appreciated
if you could support me by giving advice in writing efficient code or directing me to the right resources or anything that would help me be a practical engineer.
